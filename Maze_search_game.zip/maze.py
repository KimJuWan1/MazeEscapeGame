import random
import pygame
from config import MAZE_WIDTH, MAZE_HEIGHT, CELL_SIZE

def generate_maze(width, height):
    maze = [[1 for _ in range(width)] for _ in range(height)]
    stack = []
    start_x, start_y = random.randrange(1, width, 2), random.randrange(1, height, 2)
    maze[start_y][start_x] = 0
    stack.append((start_x, start_y))
    while stack:
        x, y = stack[-1]
        directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
        random.shuffle(directions)
        moved = False
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < width and 0 <= ny < height and maze[ny][nx] == 1:
                maze[ny][nx] = 0
                maze[y + dy//2][x + dx//2] = 0
                stack.append((nx, ny))
                moved = True
                break
        if not moved:
            stack.pop()
    return maze

def find_start(maze):
    for y in range(MAZE_HEIGHT):
        for x in range(MAZE_WIDTH):
            if maze[y][x] == 0:
                return (x, y)
    return (1, 1)

def find_exit(maze):
    for y in reversed(range(MAZE_HEIGHT)):
        for x in reversed(range(MAZE_WIDTH)):
            if maze[y][x] == 0:
                return (x, y)
    return (MAZE_WIDTH-2, MAZE_HEIGHT-2)

def draw_maze(screen, maze, player_pos, exit_pos, wall_img, exit_img, player_img, CELL_SIZE):
    for y in range(MAZE_HEIGHT):
        for x in range(MAZE_WIDTH):
            rect = pygame.Rect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            if (x, y) == exit_pos:
                screen.blit(exit_img, rect)
            elif maze[y][x] == 1:
                screen.blit(wall_img, rect)
            else:
                pygame.draw.rect(screen, (30, 30, 30), rect)

    px, py = player_pos
    player_rect = pygame.Rect(px * CELL_SIZE, py * CELL_SIZE, CELL_SIZE, CELL_SIZE)
    screen.blit(player_img, player_rect)

def find_dead_end_positions(maze):
    dead_ends = []
    for y in range(1, MAZE_HEIGHT-1):
        for x in range(1, MAZE_WIDTH-1):
            if maze[y][x] == 0:
                wall_count = 0
                for dx, dy in [(-1,0), (1,0), (0,-1), (0,1)]:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < MAZE_WIDTH and 0 <= ny < MAZE_HEIGHT:
                        if maze[ny][nx] == 1:
                            wall_count += 1
                if wall_count == 3:
                    dead_ends.append((x, y))
    return dead_ends
