###게임 전체에서 공통으로 사용할 "값"만 모아놓은 곳
###화면크기,색깔,게임상태 등 정리리

import pygame

# 화면 설정
CELL_SIZE = 32
MAZE_WIDTH, MAZE_HEIGHT = 31, 31
SCREEN_WIDTH = CELL_SIZE * MAZE_WIDTH
SCREEN_HEIGHT = CELL_SIZE * MAZE_HEIGHT + 100

# 게임 설정
FPS = 60
TIME_LIMIT = 180

# 색상
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
LIGHT_GREY = (200, 200, 200)
RED = (255, 0, 0)

# 게임 상태
STATE_START = 0
STATE_PLAYING = 1
STATE_WIN = 2
STATE_LOSE = 3

# 힌트 키워드
HINT_KEYWORDS = ["hint", "help", "guide", "direction", "assist", "lost"]

# 폰트 초기화
pygame.font.init()
FONT = pygame.font.SysFont("arial", 20)
BIG_FONT = pygame.font.SysFont("arial", 30)
LARGE_FONT = pygame.font.SysFont("arial", 60)
