from collections import deque
from config import MAZE_WIDTH, MAZE_HEIGHT

# -----------------------------------------------
# BFS 최단 경로 탐색 함수
# 시작 위치(start)부터 목표 위치(goal)까지 가장 짧은 경로를 찾아 리스트로 반환한다.
# -----------------------------------------------
def bfs(maze, start, goal):
    queue = deque([start])                                       # 시작점을 큐에 넣고 시작
    visited = {start: None}                                      # 방문한 노드와 직전 노드 기록

    while queue:
        x, y = queue.popleft()

        # 목표(goal) 위치에 도달했으면 탐색 종료
        if (x, y) == goal:
            break

        # 상하좌우 이동
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nx, ny = x + dx, y + dy

            # 미로 범위 안에 있고, 이동 가능한 길(0)이고, 아직 방문하지 않은 곳이라면
            if 0 <= nx < MAZE_WIDTH and 0 <= ny < MAZE_HEIGHT:
                if maze[ny][nx] == 0 and (nx, ny) not in visited:
                    visited[(nx, ny)] = (x, y)                   # 현재 위치(x,y)를 기록
                    queue.append((nx, ny))                       # 다음에 방문할 곳으로 추가

    # 경로 복원
    path = []
    at = goal
    if at not in visited:
        return []                                                # goal까지 갈 수 없는 경우 (길이 없는 경우)

    # goal에서 start까지 역추적해서 경로 만들기
    while at:
        path.append(at)
        at = visited[at]
    path.reverse()                                               # 역순 다시 뒤집기 (start -> goal 순서로)

    return path                                                  # 최종 경로 리스트 반환
