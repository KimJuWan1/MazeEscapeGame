import random
from utils import bfs
from maze import find_dead_end_positions

# -----------------------------------------------
# 몬스터를 생성하는 함수
# 플레이어와 출구의 경로에 방해가 되지 않는 안전한 dead_ends 지점에 몬스터를 소환
# -----------------------------------------------
def spawn_monster(maze, exit_pos, player_pos):
    dead_ends = find_dead_end_positions(maze)                                           # 미로에서 막다른 길(dead-end) 위치 찾기
    path = bfs(maze, player_pos, exit_pos)                                              # 플레이어 출발 위치에서 출구까지 가는 최단 경로 찾기
    safe_dead_ends = [pos for pos in dead_ends if pos not in path and pos != exit_pos]  # 경로를 막지 않는 dead-end만 고름
    return random.choice(safe_dead_ends) if safe_dead_ends else None                    # 랜덤으로 몬스터 배치 (없으면 None)

# -----------------------------------------------
# 플레이어와 몬스터의 거리를 계산해서 추격하는 함수
# (5칸 이내이면 추격 시작)
# -----------------------------------------------
def is_within_chase_distance(player_pos, monster_pos, maze, distance=5):
    path = bfs(maze, monster_pos, player_pos)                                           # 몬스터 위치에서 플레이어까지 최단 경로 찾기
    return path and len(path) - 1 <= distance                                           # 경로 길이가 설정된 거리(distance) 이내면 True

# -----------------------------------------------
# 몬스터가 한 칸 움직이는 함수
# 몬스터가 플레이어를 향해 경로를 따라 한 칸씩 이동
# -----------------------------------------------
def move_monster(monster_pos, player_pos, maze):
    path = bfs(maze, monster_pos, player_pos)                                           # 몬스터에서 플레이어까지 최단 경로
    if len(path) >= 2:
        return path[1]                                                                  # 다음 이동할 위치 반환 (한 칸만 이동)
    else:
        return monster_pos                                                              # 이동할 수 없으면 제자리에 그대로
