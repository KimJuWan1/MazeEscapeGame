import re
from utils import bfs
from config import MAZE_WIDTH, MAZE_HEIGHT, HINT_KEYWORDS

# -----------------------------------------------
# 플레이어 위치와 출구를 기준으로 "다음 이동 방향 힌트"를 생성해주는 함수
# -----------------------------------------------
def get_hint(maze, player_pos, exit_pos):
    path = bfs(maze, player_pos, exit_pos)                # 현재 위치에서 출구까지 가는 최단 경로 계산
    if len(path) >= 2:
        next_pos = path[1]                                # 다음 이동할 좌표
        dx = next_pos[0] - player_pos[0]
        dy = next_pos[1] - player_pos[1]
        if dx == 1:
            return "Move to the right! You can keep going"
        if dx == -1:
            return "Move to the left! You can keep going"
        if dy == 1:
            return "Move downward! You can keep going"
        if dy == -1:
            return "Move upward! You can keep going"
    return "No path found."                               # 이동 경로를 찾을 수 없는 경우

# -----------------------------------------------
# 플레이어가 입력한 대화(user_input)를 분석해서 AI 답변을 생성하는 함수
# -----------------------------------------------
def analyze_meaning(user_input, maze, player_pos, exit_pos):
    user_input = user_input.lower()                       # 모두 소문자로 변환
    user_input = re.sub(r'[^a-z0-9\s]', '', user_input)   # 영어, 숫자, 공백 제외하고 모두 제거

    path = bfs(maze, player_pos, exit_pos)                # 현재 위치에서 출구까지 최단 경로
    if not path:
        return "I can't find a path right now."           # 길을 찾을 수 없는 경우

    # 현재 출구까지의 "대략적 거리"를 %로 환산
    max_distance = MAZE_WIDTH + MAZE_HEIGHT
    current_distance = abs(exit_pos[0] - player_pos[0]) + abs(exit_pos[1] - player_pos[1])
    success_rate = int((1 - current_distance / max_distance) * 100)

    # 대화 내용에 따라 다양한 답변 반환
    if "hi" in user_input or "hello" in user_input:
        return "Hi, I'm Maze Escape Helper! I help you to escape this maze."
    if "name" in user_input:
        return "My name is juwan"
    if "pretty" in user_input:
        return "Thank you, you are nice!"
    if "meet" in user_input:
        return "I'm happy to meet you too!"
    if "love" in user_input or "hate" in user_input:
        return "I love you!"
    if "cant" in user_input:
        return "Cheer up!! You can escape this maze!"
    if "lost" in user_input or "confused" in user_input:
        return "You can escape this maze! Please request a hint!"
    if "destination" in user_input or "exit" in user_input:
        return "Find your way to the yellow exit!"
    if "leave" in user_input or "where" in user_input or "location" in user_input:
        return f"You are {success_rate}% closer to the exit."

    # 그 외의 경우 (기본 응답)
    return "Be quiet and concentrate to escape this maze! I can give you a hint."

# -----------------------------------------------
# 플레이어 입력이 힌트 요청인지 아닌지를 판별하는 함수
# (hint 키워드가 포함되어 있는지 검사)
# -----------------------------------------------
def is_hint_request(text):
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', '', text)                    # 영어, 숫자, 공백 제외하고 모두 제거
    return any(keyword in text for keyword in HINT_KEYWORDS)   # hint 관련 키워드가 들어있으면 True

