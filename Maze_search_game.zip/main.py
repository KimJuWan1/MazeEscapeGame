import pygame
from config import *
from assets import screen, player_img, wall_img, exit_img, opening_img, ai_img, monster_img
from maze import generate_maze, find_start, find_exit, draw_maze
from monster import spawn_monster, is_within_chase_distance, move_monster
from ai_helper import get_hint, analyze_meaning, is_hint_request

# --- 게임 초기화 ---
maze = generate_maze(MAZE_WIDTH, MAZE_HEIGHT)
player_pos = find_start(maze)
exit_pos = find_exit(maze)

monster_positions = [spawn_monster(maze, exit_pos, player_pos) for _ in range(4)]
chasings = [False for _ in range(4)]  # 몬스터별 추격 여부
monster_move_delay = 500  # 밀리초
last_monster_move_time = pygame.time.get_ticks()

input_mode = False
input_text = ""
hint_message = ""
start_ticks = pygame.time.get_ticks()
game_state = STATE_START

clock = pygame.time.Clock()
running = True

# --- 메인 루프 ---
while running:
    screen.fill(BLACK)
    elapsed_time = (pygame.time.get_ticks() - start_ticks) // 1000
    remaining_time = max(0, TIME_LIMIT - elapsed_time)

    if game_state == STATE_START:
        screen.blit(opening_img, (0, 0))

    elif game_state == STATE_PLAYING:
        draw_maze(screen, maze, player_pos, exit_pos, wall_img, exit_img, player_img, CELL_SIZE)

        # 플레이어 주변만 밝게 (시야 제한)
        vision = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT-100), pygame.SRCALPHA)
        vision.fill((0, 0, 0, 255))
        center_x = player_pos[0] * CELL_SIZE + CELL_SIZE // 2
        center_y = player_pos[1] * CELL_SIZE + CELL_SIZE // 2
        pygame.draw.circle(vision, (0, 0, 0, 0), (center_x, center_y), CELL_SIZE * 4)
        screen.blit(vision, (0, 0))

        # 타이머 표시
        time_color = RED if remaining_time <= 30 else WHITE
        timer_surface = FONT.render(f"Time Left: {remaining_time} sec", True, time_color)
        screen.blit(timer_surface, (20, 10))

        # 하단 회색 박스 + 안내 문구
        pygame.draw.rect(screen, (220, 220, 220), (0, SCREEN_HEIGHT-100, SCREEN_WIDTH, 100))
        guide_surface = BIG_FONT.render("Press [H] and ask me hint! (Please question in English)", True, BLACK)
        screen.blit(guide_surface, (120, SCREEN_HEIGHT-90))
        pygame.draw.rect(screen, (180, 180, 180), (110, SCREEN_HEIGHT-50, SCREEN_WIDTH-120, 40), border_radius=10)

        # 입력창 or 힌트 메시지
        if input_mode:
            input_surface = FONT.render(input_text, True, BLACK)
            screen.blit(input_surface, (120, SCREEN_HEIGHT-40))
        else:
            hint_surface = FONT.render(hint_message, True, BLACK)
            screen.blit(hint_surface, (120, SCREEN_HEIGHT-40))

        # AI 도우미
        screen.blit(ai_img, (5, SCREEN_HEIGHT-130))

        # 몬스터 표시 및 이동
        current_time = pygame.time.get_ticks()
        for idx, monster_pos in enumerate(monster_positions):
            if monster_pos:
                distance = abs(player_pos[0] - monster_pos[0]) + abs(player_pos[1] - monster_pos[1])
                if distance <= 4:
                    rect = pygame.Rect(monster_pos[0] * CELL_SIZE, monster_pos[1] * CELL_SIZE, CELL_SIZE, CELL_SIZE)
                    screen.blit(monster_img, rect)

                if not chasings[idx]:
                    chasings[idx] = is_within_chase_distance(player_pos, monster_pos, maze)

                if chasings[idx] and current_time - last_monster_move_time > monster_move_delay:
                    monster_positions[idx] = move_monster(monster_pos, player_pos, maze)

                if monster_positions[idx] == player_pos:
                    game_state = STATE_LOSE

        if current_time - last_monster_move_time > monster_move_delay:
            last_monster_move_time = current_time

    elif game_state == STATE_WIN:
        draw_maze(screen, maze, player_pos, exit_pos, wall_img, exit_img, player_img, CELL_SIZE)
        win_text = LARGE_FONT.render("You Escaped!", True, (0, 200, 255))
        restart_surface = FONT.render("[Press R] to Restart", True, LIGHT_GREY)
        screen.blit(win_text, win_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2-30)))
        screen.blit(restart_surface, restart_surface.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2+40)))

    elif game_state == STATE_LOSE:
        screen.fill(BLACK)
        lose_text = LARGE_FONT.render("You Died", True, RED)
        restart_surface = FONT.render("[Press R] to Restart", True, LIGHT_GREY)
        screen.blit(lose_text, lose_text.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2-30)))
        screen.blit(restart_surface, restart_surface.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2+40)))

    # 이벤트 처리
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if game_state == STATE_START:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                maze = generate_maze(MAZE_WIDTH, MAZE_HEIGHT)
                player_pos = find_start(maze)
                exit_pos = find_exit(maze)
                monster_positions = [spawn_monster(maze, exit_pos, player_pos) for _ in range(4)]
                chasings = [False for _ in range(4)]
                last_monster_move_time = pygame.time.get_ticks()
                input_text = ""
                hint_message = ""
                input_mode = False
                start_ticks = pygame.time.get_ticks()
                game_state = STATE_PLAYING

        elif game_state == STATE_PLAYING:
            if input_mode:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        if is_hint_request(input_text):
                            hint_message = get_hint(maze, player_pos, exit_pos)
                        else:
                            hint_message = analyze_meaning(input_text, maze, player_pos, exit_pos)
                        input_text = ""
                        input_mode = False
                    elif event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    else:
                        input_text += event.unicode
            else:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_h:
                        input_mode = True
                        input_text = ""
                    if event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]:
                        dx, dy = 0, 0
                        if event.key == pygame.K_UP:
                            dy = -1
                        elif event.key == pygame.K_DOWN:
                            dy = 1
                        elif event.key == pygame.K_LEFT:
                            dx = -1
                        elif event.key == pygame.K_RIGHT:
                            dx = 1
                        nx, ny = player_pos[0] + dx, player_pos[1] + dy
                        if 0 <= nx < MAZE_WIDTH and 0 <= ny < MAZE_HEIGHT and maze[ny][nx] == 0:
                            player_pos = (nx, ny)

            if player_pos == exit_pos:
                game_state = STATE_WIN

            if remaining_time == 0 and player_pos != exit_pos:
                game_state = STATE_LOSE

        elif game_state in [STATE_WIN, STATE_LOSE]:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                maze = generate_maze(MAZE_WIDTH, MAZE_HEIGHT)
                player_pos = find_start(maze)
                exit_pos = find_exit(maze)
                monster_positions = [spawn_monster(maze, exit_pos, player_pos) for _ in range(4)]
                chasings = [False for _ in range(4)]
                last_monster_move_time = pygame.time.get_ticks()
                input_text = ""
                hint_message = ""
                input_mode = False
                start_ticks = pygame.time.get_ticks()
                game_state = STATE_START

    pygame.display.update()
    clock.tick(FPS)

pygame.quit()

