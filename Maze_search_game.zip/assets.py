import pygame
from config import SCREEN_WIDTH, SCREEN_HEIGHT, CELL_SIZE

pygame.init()
pygame.mixer.init()

# 배경음악
pygame.mixer.music.load("background_music.mp3")
pygame.mixer.music.play(-1)

# 화면
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Maze Escape!")

# 이미지 로딩 및 크기 조정
player_img = pygame.transform.scale(pygame.image.load("player.png"), (CELL_SIZE, CELL_SIZE))
wall_img = pygame.transform.scale(pygame.image.load("wall.png"), (CELL_SIZE, CELL_SIZE))
exit_img = pygame.transform.scale(pygame.image.load("exit.png"), (CELL_SIZE, CELL_SIZE))
opening_img = pygame.transform.scale(pygame.image.load("opening.png"), (SCREEN_WIDTH, SCREEN_HEIGHT))
ai_img = pygame.transform.scale(pygame.image.load("ai_helper.png"), (100, 120))
monster_img = pygame.transform.scale(pygame.image.load("monster.png"), (CELL_SIZE, CELL_SIZE))
